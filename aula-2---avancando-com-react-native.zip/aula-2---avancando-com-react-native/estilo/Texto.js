import {StyleSheet} from "react-native"

export default StyleSheet.create({
  titulo: {
    fontSize: 23, 
    color: "#fff"
  }, 
  subtitulo: {
    fontSize: 18,
    color: "yellow"
  }, 
  textoPadrao: {
    fontSize: 12, 
    color: "#fff"
  }
})
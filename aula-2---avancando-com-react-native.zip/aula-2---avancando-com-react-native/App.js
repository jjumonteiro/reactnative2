import * as React from 'react';
import { Button, View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';

export default function App() {
  return (
    <View style={estilo.conteudo}>
      <Pressable onPress={() => alert("OI")}>
        <Text>Clique Aqui</Text>
      </Pressable>
    </View>
  );
}

const estilo = StyleSheet.create({
  conteudo: {
    flex: 1,
    backgroundColor: "#42474d",
    paddingTop: 300
  }
})

import {View, Text, StyleSheet} from "react-native";
import estiloTexto from "../estilo/Texto"

function PrimeiroComponent( {titulo = "Titulo", subtitulo = "Sub"} ) {
  return (
    <>
      <Text style={estiloTexto.titulo}>
        {titulo}
      </Text>
      <Text style={estiloTexto.subtitulo}>
       {subtitulo}
      </Text>
    </>  
  )
}

export default PrimeiroComponent;
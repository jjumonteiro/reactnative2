import {View, StyleSheet} from "react-native"

export default function( {cor, flex = 1} ) {
  return (
    <View style={ {
      flex: flex,
      backgroundColor: cor
    } } />
  )
}